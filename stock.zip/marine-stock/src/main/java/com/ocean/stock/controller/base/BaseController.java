package com.ocean.stock.controller.base;

public class BaseController {

}
