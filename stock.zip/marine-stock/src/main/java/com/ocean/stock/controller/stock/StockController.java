package com.ocean.stock.controller.stock;

import org.springframework.web.bind.annotation.RequestMapping;

import com.ocean.stock.controller.base.BaseController;

@RequestMapping(value="stock")
public class StockController extends BaseController{

    
}
