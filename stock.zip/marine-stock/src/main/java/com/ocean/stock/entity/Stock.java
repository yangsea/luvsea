package com.ocean.stock.entity;

public class Stock extends AbstractEntity {

    
}
