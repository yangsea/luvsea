package com.ocean.stock.service.user;

public interface UserService {

}
