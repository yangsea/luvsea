package com.ocean.stock.controller.note;

import org.springframework.web.bind.annotation.RequestMapping;

import com.ocean.common.returnobject.ReturnObject;

/** 笔记控制器*/
@RequestMapping(value="note")
public class NoteController {

    
//    public  ReturnObject<T> getNotes() {
//        // TODO Auto-generated method stub
//        
//    }
}
