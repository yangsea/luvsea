package com.ocean.common.enumeration;

public enum EnumModule {
    
    ddd

}
