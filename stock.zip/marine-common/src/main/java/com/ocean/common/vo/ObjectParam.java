package com.ocean.common.vo;

public class ObjectParam {

    private String key;
    private String args;
    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getArgs() {
        return args;
    }
    public void setArgs(String args) {
        this.args = args;
    }
    
    
}
