package testsimple;

import java.sql.Timestamp;

public class TimeTest {
    
    public static void main(String[] args) {
        
//        Long lo = System.currentTimeMillis();
//        System.out.println(lo);
//        System.out.println(lo/1000);
//        Timestamp ts = new Timestamp(lo);
//        System.out.println(ts);
//        Timestamp tsp = new Timestamp(Long.valueOf(1449834273+"625"));
//        System.out.println(tsp);
//        
        String a = "dddduidbbbbbbb";
//        int b=a.lastIndexOf("uid");
//        System.out.println(b);
        System.out.println(a= "ccc");
    }
    
}
