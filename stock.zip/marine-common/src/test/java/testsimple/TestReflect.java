package testsimple;

public class TestReflect {
    
    public  void main(String[] args) {
        
        String aaa = "dddd";
//        System.out.println(aaa.toString());
//        String "\""+aaa+"\"";
    }

}
