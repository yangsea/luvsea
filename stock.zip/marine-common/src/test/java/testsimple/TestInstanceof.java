package testsimple;

public class TestInstanceof {
    
    
    
    public static void main(String[] args) {
        String name = "James";

        boolean result = name instanceof String;
        
        System.out.println(result);
    }

}
