package testsimple;

public class TestLong {

//    float f = 3.4;
    //为float的时候最好是加上f，否则识别为double
    float f1= 2.4f;
}
