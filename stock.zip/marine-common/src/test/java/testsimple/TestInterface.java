package testsimple;

public interface TestInterface {

    String aa = "1";
    
//    private static String aaa = "";
}
