package testsimple;

public class TestIf {

    public static void main(String[] args) {
        
        if(false)
            System.out.println("true");
            System.out.println("false");
    }
}
